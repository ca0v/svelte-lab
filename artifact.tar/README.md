# Svelte + TS + Vite

Updated using `>npm create vite@latest`

See the [live](https://ca0v.github.io/svelte-lab) site.

[![run-deploy](https://github.com/ca0v/svelte-lab/actions/workflows/run-deploy.yml/badge.svg)](https://github.com/ca0v/svelte-lab/actions/workflows/run-deploy.yml)
